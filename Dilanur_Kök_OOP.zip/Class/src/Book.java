
public class Book {
String name;
int ISBN;
String author;
String publisher;


public Book(String name,int ISBN,String author,String publisher) {
	this.name=name;
	this.ISBN=ISBN;
	this.author =author;
	this.publisher=publisher;
}
public void setName(String name) {
	this.name=name;
}
public String getName() {
	return this.name;
}
public void setISBN(int ISBN) {
	this.ISBN=ISBN;
}
public int getISBN() {
	return ISBN;
}
public void setAuthor(String Author) {
	this.author=Author;
}
public String getAuthor() {
	return author;
}
public void setPublisher(String Publisher) {
	
	this.publisher = Publisher;}
	
public String getPublisher(String Author) {
	return this.publisher;
}
public String getBookDetail(){
	return name + ISBN + author + publisher;
}
}

