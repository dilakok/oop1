
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		Book books [] = new Book[5];
		books [0] = new Book ("Otomatik portakal",12345, "Anthony Burgess", "�� Bankas� Yay�nlar�");
		books [0].getBookDetail();
		//books [0].setISBN(6789); 
		books [0].getBookDetail();
		System.out.println(books[0].getBookDetail());
	}

}
